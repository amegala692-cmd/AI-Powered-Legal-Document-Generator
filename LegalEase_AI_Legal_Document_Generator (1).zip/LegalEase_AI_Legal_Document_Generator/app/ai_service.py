import os, json
from google import genai

def fallback(d):
    title=f"{d['document_type']} — Draft"
    body=f"""DRAFT {d['document_type'].upper()}

Jurisdiction: {d['jurisdiction']}
Party A: {d['party_a'] or '[Party A]'}
Party B: {d['party_b'] or '[Party B]'}

PURPOSE
{d['purpose'] or '[Describe the purpose]'}

TERMS
{d['terms'] or '[Insert agreed terms]'}

GENERAL PROVISIONS
1. The parties should review all facts and dates for accuracy.
2. Any required signatures, witnesses, notices, schedules, or annexures should be added before use.
3. Governing law and dispute-resolution provisions should be checked for the selected jurisdiction.

SIGNATURES
Party A: ____________________    Date: __________
Party B: ____________________    Date: __________
"""
    return {"title":title,"document":body,"disclaimer":"Demo draft only. This is not legal advice and should be reviewed by a qualified legal professional before use."}

def generate_document(d):
    key=os.getenv("GEMINI_API_KEY","").strip()
    if not key: return fallback(d)
    prompt=f"""
You are a legal-document drafting assistant. Create a structured FIRST DRAFT based only on the supplied facts.
Return valid JSON with exactly: title, document, disclaimer.
The document must clearly be labeled as a draft, avoid inventing facts, avoid claiming legal validity,
and include placeholders where information is missing. Jurisdiction: {d['jurisdiction']}.
Document type: {d['document_type']}. Party A: {d['party_a']}. Party B: {d['party_b']}.
Purpose: {d['purpose']}. Terms: {d['terms']}. Language: {d['language']}. Tone: {d['tone']}.
Include appropriate headings, definitions where useful, obligations, term/termination if relevant,
confidentiality if relevant, dispute/governing-law placeholder, notices, signatures, and schedules only when appropriate.
Do not provide legal advice or guarantee enforceability. For jurisdiction-specific requirements, tell the user to verify them.
"""
    try:
        client=genai.Client(api_key=key)
        r=client.models.generate_content(model=os.getenv("GEMINI_MODEL","gemini-2.5-flash"),
                                         contents=prompt,
                                         config={"response_mime_type":"application/json"})
        return json.loads(r.text)
    except Exception as e:
        raise RuntimeError("Gemini could not generate the draft. Check your API key, model, and internet connection.") from e
