from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from .ai_service import generate_document

load_dotenv()
BASE=Path(__file__).resolve().parent
app=FastAPI(title="LegalEase - AI Legal Document Generator",version="1.0.0")
app.mount("/static",StaticFiles(directory=BASE/"static"),name="static")

class DocumentRequest(BaseModel):
    document_type:str
    jurisdiction:str="India"
    party_a:str=Field(default="",max_length=200)
    party_b:str=Field(default="",max_length=200)
    purpose:str=Field(default="",max_length=2000)
    terms:str=Field(default="",max_length=5000)
    language:str="English"
    tone:str="Professional"

@app.get("/",response_class=HTMLResponse)
def home():
    return (BASE/"static/index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health(): return {"status":"ok","service":"LegalEase"}

@app.post("/api/generate")
def generate(req:DocumentRequest):
    try: return generate_document(req.model_dump())
    except RuntimeError as e: raise HTTPException(status_code=503,detail=str(e))
    except Exception: raise HTTPException(status_code=500,detail="Document generation failed.")
