# LegalEase — AI-Powered Legal Document Generator

Full-stack educational prototype using FastAPI + Gemini + HTML/CSS/JavaScript.

## Features
- Document type selection
- Jurisdiction, parties, purpose and key terms
- Gemini-powered first-draft generation
- Demo fallback without an API key
- Print / Save as PDF from the browser
- Strong legal disclaimer and no automatic claim of enforceability
- No account or database in this starter

## Run
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env`, then add your Gemini API key. Without a key, the app produces a clearly labeled demo draft.

```bash
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/docs

## Production extensions
Authentication, encrypted persistence, audit logs, document versioning, templates, lawyer review workflow, rate limiting, jurisdiction-specific validation, citations to authoritative legislation, and secure deployment should be added before real-world use.

## Legal/safety note
AI-generated documents can contain omissions or errors and may not satisfy local formalities. This project is for educational prototyping. A qualified lawyer should review a document before it is signed, filed, or relied upon.
